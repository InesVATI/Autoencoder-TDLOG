Clazz.declarePackage ("JS");
Clazz.load (["JS.JMenuItem"], "JS.JCheckBoxMenuItem", null, function () {
c$ = Clazz.declareType (JS, "JCheckBoxMenuItem", JS.JMenuItem);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, JS.JCheckBoxMenuItem, ["chk", 2]);
});
});
