Clazz.declarePackage ("JSV.api");
Clazz.load (["JSV.api.JSVViewPanel"], "JSV.api.JSVPanel", null, function () {
Clazz.declareInterface (JSV.api, "JSVPanel", JSV.api.JSVViewPanel);
});
